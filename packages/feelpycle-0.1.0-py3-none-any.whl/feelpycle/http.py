import datetime
import logging
import os
import pathlib
import pickle
import random
import tempfile
import time

import requests
import requests.adapters
import urllib3.util

LOGGER = logging.getLogger(__name__)


class RatedHttpSession:
    def __init__(
        self,
        resp_storage: str,
        resp_save_code="utf-8",
        cooldown_ms=600,
    ):
        s = requests.Session()
        retries = urllib3.util.retry.Retry(
            total=5, backoff_factor=1, status_forcelist=[500, 502, 503, 504]
        )
        s.mount("https://", requests.adapters.HTTPAdapter(max_retries=retries))
        s.mount("http://", requests.adapters.HTTPAdapter(max_retries=retries))
        self.session_ = s
        self.last_called_ = 0.0
        self.resp_storage_ = resp_storage
        self.resp_save_code_ = resp_save_code
        self.cooldown_ = cooldown_ms / 1000.0

    def add_fixed_header(self, header: dict[str, str]):
        self.session_.headers.update(header)

    def _do_request(self, **kwargs):
        time.sleep(
            max(
                0,
                (self.last_called_ + self.cooldown_)
                - time.monotonic()
                + random.triangular(-0.1, 0.1),
            )
        )
        self.last_called_ = time.monotonic()
        response = self.session_.request(**kwargs)
        method, url, data = (kwargs["method"], kwargs["url"], kwargs.get("data", None))

        dir = pathlib.Path(tempfile.gettempdir(), self.resp_storage_)
        dir.mkdir(exist_ok=True)
        path = dir / datetime.datetime.strftime(
            datetime.datetime.now(), "resp-%Y%m%dT%H%M%S.%f.txt"
        )
        path.write_text(response.text, self.resp_save_code_)
        LOGGER.debug(f"Request {method=}, {url=}, {data=}, response_data_path={path}")

        response.raise_for_status()
        return response

    def get_session_state(self) -> dict[str, dict[str, str]]:
        return {
            "cookies": requests.utils.dict_from_cookiejar(self.session_.cookies),
            "headers": dict(self.session_.headers),
        }

    def set_session_state(self, state: dict[str, dict[str, str]]) -> None:
        cookies = state.get("cookies", {})
        headers = state.get("headers", {})
        self.session_.cookies.update(cookies)
        self.session_.headers.update(headers)

    def persist_session(self, path: str | os.PathLike) -> None:
        state = self.get_session_state()
        with open(path, "wb") as f:
            pickle.dump(state, f)

    def restore_session(self, path: str | os.PathLike) -> None:
        with open(path, "rb") as f:
            data = pickle.load(f)
            if not isinstance(data, dict):
                raise ValueError("Invalid session state data format")
            self.set_session_state(data)
