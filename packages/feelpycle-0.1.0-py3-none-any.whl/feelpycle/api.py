import datetime
import functools
import json
import logging
import os
import re
from collections.abc import Container

import pydantic

from . import http, studios

LOGGER = logging.getLogger(__name__)
COOLDOWN = 650
USER_AGENT = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36"
YYYYMM_PATTERN = re.compile(r"20\d{2}(0[1-9]|1[0-2])")


class ProgramSearch(pydantic.BaseModel):
    id: int
    name: str


class GenreSearch(pydantic.BaseModel):
    key: int
    name: str
    id_list: list[int]


class Instructor(pydantic.BaseModel):
    id: int  # 101
    name: str  # "D.John"

    @pydantic.field_validator("id", mode="before")
    def parse_id(cls, v):
        return int(v)


class InstructorSearch(pydantic.BaseModel):
    id: int
    name: str


class LessonInfo(pydantic.BaseModel):
    sid: str  # "4da7fa6bbfc23..."
    shift_date: datetime.date  # "2023/08/01"
    ls_st: datetime.time  # "21:30:00"
    ls_et: datetime.time  # "22:15:00"
    store_name: str  # "新宿（SJK）"
    iname: str  # "BB1 COMP 1"
    instructor_name_list: list[Instructor]
    sheet_no: int  # 8
    ticket_name: str | None  # "マンスリー1回券"
    program_search: ProgramSearch
    genre_search: GenreSearch | list
    instructor_search: InstructorSearch
    playlist_url: str  # "https://music.apple.com/jp/playlist/bb1-comp1/pl.644aaf79870d4d95859f3e44813d6fd4"
    cancel_flg: int
    cancel_cancel_flg: int
    id: str | None = None
    icon: str | None = None

    @pydantic.field_validator("shift_date", mode="before")
    def parse_date(cls, d):
        return datetime.datetime.strptime(d, "%Y/%m/%d").date()

    @pydantic.field_validator("iname", mode="before")
    def normalize_iname(cls, v):
        return re.sub(r" +", " ", v)


class MonthHistory(pydantic.BaseModel):
    summary_count: int
    member_count: int
    ticket_count: int
    lesson_info: list[LessonInfo]


class YearMonth:
    def __init__(self, year: int, month: int):
        if not (1900 < year < 2200 and 1 <= month <= 12):
            raise ValueError("Invalid year/month")
        self.month_serial_ = year * 12 + month - 1

    def year(self):
        return self.month_serial_ // 12

    def month(self):
        return self.month_serial_ % 12 + 1

    def to_yyyymm(self):
        return f"{self.year():04d}{self.month():02d}"

    def year_month(self):
        return self.year(), self.month()

    def __eq__(self, other):
        if isinstance(other, YearMonth):
            return self.month_serial_ == other.month_serial_
        return False

    def __ne__(self, other):
        return not self.__eq__(other)

    def __lt__(self, other):
        if isinstance(other, YearMonth):
            return self.month_serial_ < other.month_serial_
        raise TypeError("Cannot compare YearMonth with non-YearMonth object")

    def __le__(self, other):
        return not (other < self)

    def __gt__(self, other):
        return other < self

    def __ge__(self, other):
        return other <= self

    def __hash__(self):
        return hash(self.month_serial_)

    def __add__(self, months: int):
        new = YearMonth(*self.year_month())
        new.month_serial_ += months
        return new

    def __sub__(self, months: int):
        return self + (-months)

    def __repr__(self):
        return self.to_yyyymm()

    @staticmethod
    def range(start: "YearMonth", end: "YearMonth", step=1):
        current = start
        while current <= end:
            yield current
            current += step

    @staticmethod
    def from_yyyymm(yyyymm: str):
        if not YYYYMM_PATTERN.match(yyyymm):
            raise ValueError("Invalid yyyymm format")
        return YearMonth(int(yyyymm[:4]), int(yyyymm[4:6]))


def determine_fetch_center_month(
    target_month: YearMonth,
    cached_months: Container[YearMonth],
) -> YearMonth:
    """Determine the optimal center month to fetch for lesson history.

    Selects the 3-consecutive-month window (out of 5 months centered around target_month)
    that contains the maximum number of uncached months.
    If multiple windows have the same maximum count, the window where target_month is the latest
    (i.e., the older range) is preferred.
    Returns the center month of the selected window.
    """
    candidates = [
        (target_month - 1, (target_month - 2, target_month - 1, target_month)),
        (target_month, (target_month - 1, target_month, target_month + 1)),
        (target_month + 1, (target_month, target_month + 1, target_month + 2)),
    ]

    best_center = candidates[0][0]
    max_missing = -1

    for center, window in candidates:
        missing = sum(1 for m in window if m not in cached_months)
        if missing > max_missing:
            max_missing = missing
            best_center = center

    return best_center


class LessonHistory(pydantic.BaseModel):
    model_config = {"arbitrary_types_allowed": True}

    monthly_history: dict[YearMonth, MonthHistory]
    result_code: int
    error_messages: str
    memtype: int

    @pydantic.model_validator(mode="before")
    @classmethod
    def parse_monthly_history(cls, data):
        if isinstance(data, dict):
            data["monthly_history"] = {
                YearMonth.from_yyyymm(k): MonthHistory.model_validate(v)
                for k, v in data.items()
                if YYYYMM_PATTERN.match(k)
            }
            assert isinstance(data["monthly_history"], dict)
            for k, v in data["monthly_history"].items():
                assert isinstance(k, YearMonth)
                assert isinstance(v, MonthHistory)

            # sort lesson_info by date and time for each month to make it easier to find the first lesson date
            for v in data["monthly_history"].values():
                v.lesson_info.sort(key=lambda x: (x.shift_date, x.ls_st))

        return data


class TextNews(pydantic.BaseModel):
    info_id: int
    info_type: int
    title: str
    html_path: str
    release_start_date: datetime.date

    @pydantic.field_validator("release_start_date", mode="before")
    def parse_date(cls, d):
        return datetime.datetime.strptime(d, "%Y/%m/%d").date()


class BannerNews(pydantic.BaseModel):
    info_id: int
    image_path: str


class ReservationStatus(pydantic.BaseModel):
    trial_flg: int
    oid: int
    cancel_total_num: int
    cancel_my_num: int
    reservation_store: str
    reservation_store_id: int
    sheet_num: int
    lesson_date: datetime.date
    lesson_start_time: datetime.time
    lesson_end_time: datetime.time
    lesson_name: str
    teacher_name_list: list[Instructor]
    uid: int
    playlist_path: str
    ticket_name: str
    trial_invite_url: str
    payment_method: int
    ticket_expire: str
    lesson_cancel_ng: int
    sid_hash: str
    itxtcol: str
    ibgcol: str
    id: str | None = None
    icon: str | None = None

    @pydantic.field_validator("lesson_date", mode="before")
    def parse_date(cls, d):
        return datetime.datetime.strptime(d, "%Y/%m/%d").date()


class MyPage(pydantic.BaseModel):
    result_code: int
    member_name: str
    mid: int
    member_type: str
    store: list[str]
    lesson_num: int
    member_type_change: int
    normal_news: list[TextNews]
    banner_news: list[BannerNews]
    friend_invite_url: str
    reservation_num: int
    reservation_status: list[ReservationStatus]
    mgid: int
    trial_flg: int
    trial_permit_flg: int
    total_attendance_num: int
    owned_ticket_num: int
    display_button_type: int


class UserName(pydantic.BaseModel):
    id: int
    name: str


class Schedule(pydantic.BaseModel):
    sid_hash: str
    lesson_name: str
    lesson_start: datetime.time
    lesson_end: datetime.time
    lesson_period: int
    user_name_list: list[UserName]
    status: int
    mess_flg: int
    reserve_status: int
    reserve_status_count: int
    itxtcol: str
    ibgcol: str
    store_id: int
    store_name: str
    custom_icon_list: list


class LessonList(pydantic.BaseModel):
    lesson_date: datetime.date
    schedule: list[Schedule]

    @pydantic.field_validator("lesson_date", mode="before")
    def parse_date(cls, d):
        return datetime.datetime.strptime(d, "%Y%m%d").date()


class ShujikuTab(pydantic.BaseModel):
    id: int
    name: str
    code: str


class LessonCalendar(pydantic.BaseModel):
    result_code: int
    mode: str
    shujiku_type: str
    lesson_list: list[LessonList]
    shujiku_tab: list[ShujikuTab]


class Position(pydantic.BaseModel):
    x: float
    y: float


class MappingAddr(pydantic.BaseModel):
    instructor: Position
    bikes: object  # Position of bikes
    nullBikes: list


class Lesson(pydantic.BaseModel):
    result_code: int
    modal_type: int
    lesson_date: datetime.date
    lesson_day_week: str
    lesson_start_time: datetime.time
    lesson_end_time: datetime.time
    reserve_limit: int
    reserve_cancel_limit: int
    current_date: datetime.date
    current_time: datetime.time
    stid: str
    store_name: str
    lesson_name: str
    instructor_name_list: list[Instructor]
    trial_flg: int
    trial_capacity: int
    checkin_flg: int
    instructor_image_path: str
    bike_map_image_path: str
    bike_map_width: int
    bike_map_height: int
    mappting_addr: MappingAddr
    bike_layout_group_list: list
    bike_status_list: object  # vacancy of bikes

    @pydantic.field_validator("lesson_date", mode="before")
    def parse_lesson_date(cls, d):
        return datetime.datetime.strptime(d, "%Y/%m/%d").date()

    @pydantic.field_validator("current_date", mode="before")
    def parse_current_date(cls, d):
        return datetime.datetime.strptime(d, "%Y/%m/%d").date()


class StoreInfo(pydantic.BaseModel):
    stid: int
    store_name: str
    seq: int
    mstore_explain: str | None
    store_lat: str | None
    store_lng: str | None
    near_station: str | None
    trial_member_near_station: str
    active_flg: int


class PrefInfo(pydantic.BaseModel):
    pref_cd: int
    pref_name: str
    store_count: int
    store_info: list[StoreInfo]


class AreaInfo(pydantic.BaseModel):
    area_name: str
    area_lat: str
    area_lng: str
    pref_count: int
    pref_info: list[PrefInfo]


class StudioListResponse(pydantic.BaseModel):
    result_code: int
    cid: int
    cust_addr: str
    memtype: int
    area_info: list[AreaInfo]
    priority_store_list: dict


class Account:
    def __init__(self, id: str | None = None, icon: str | None = None):
        self.http_session_ = http.RatedHttpSession(
            resp_storage="feelpycle",
            resp_save_code="utf-8",
            cooldown_ms=COOLDOWN,
        )
        self.http_session_.add_fixed_header(
            {
                "accept": "application/json, text/plain, */*",
                "accept-encoding": "gzip, deflate",
                "accept-language": "ja-JP,ja;q=0.9,en-US;q=0.8,en;q=0.7",
                "authority": "m.feelcycle.com",
                "cache-control": "no-cache",
                "content-type": "application/json;charset=UTF-8",
                "pragma": "no-cache",
                "user-agent": USER_AGENT,
                "x-requested-with": "XMLHttpRequest",
            }
        )
        self.base_url_ = "https://m.feelcycle.com"
        self.default_referer_ = "https://m.feelcycle.com/mypage"
        self.history_cache_: dict[YearMonth, MonthHistory] = {}
        self.id_ = None
        self.id_ = id
        self.icon_ = icon
        self.get_lesson_calendar_by_store = functools.cache(
            self.get_lesson_calendar_by_store_nocache
        )

    @property
    def id(self) -> str | None:
        return self.id_

    @id.setter
    def id(self, value: str | None) -> None:
        self.id_ = value

    @property
    def icon(self) -> str | None:
        return self.icon_

    @icon.setter
    def icon(self, value: str | None) -> None:
        self.icon_ = value

    def get_session_state(self) -> dict[str, dict[str, str]]:
        return self.http_session_.get_session_state()

    def set_session_state(self, state: dict[str, dict[str, str]]) -> None:
        self.http_session_.set_session_state(state)

    def persist_session(self, path: str | os.PathLike) -> None:
        self.http_session_.persist_session(path)

    def restore_session(self, path: str | os.PathLike) -> None:
        self.http_session_.restore_session(path)

    def _update_crsf_token_from_remote(self):
        response = self.http_session_._do_request(
            method="GET",
            url="https://m.feelcycle.com/mypage",
            headers={"referer": "https://www.feelcycle.com/"},
        )
        response.raise_for_status()
        match = re.search(
            r'<meta\s+name=["\']csrf-token["\']\s+content=["\']([^"\']+)["\']',
            response.text,
        )
        assert match, "CSRF token not found in response text"
        crsf_token = match.group(1)
        LOGGER.info(f"Updated CSRF token: {crsf_token}")
        self.http_session_.add_fixed_header({"x-csrf-token": crsf_token})
        return crsf_token

    def _call(
        self,
        url: str,
        referer=None,
        post_data="",
        *,
        method="post",
        params: dict | None = None,
        timeout=3.5,
    ):
        response = self.http_session_._do_request(
            method=method,
            url=url,
            headers={"referer": referer or self.default_referer_},
            data=post_data,
            params=params,
            timeout=timeout,
        )
        return response

    def is_logged_in(self):
        try:
            self.mypage()
            return True
        except Exception:
            return False

    def login(self, id: str, password: str):
        try:
            self._update_crsf_token_from_remote()
            payload = {
                "mail_address": id,
                "login_pass": password,
                "auto_login": 1,
            }
            response = self._call(
                url=f"{self.base_url_}/api/user/login",
                post_data=json.dumps(payload),
            )
            respjson = response.json()
            if respjson["result_code"] == 0:
                self.id_ = id
                return True
            else:
                LOGGER.error(f"Login failed: {respjson['message']}")
                return False
        except Exception as e:
            LOGGER.error(f"Login failed: {e}")
            return False

    def logout(self):
        self.http_session_.session_.cookies.clear()
        self.history_cache_.clear()
        self.id_ = None

    def mypage(self):
        response = self._call(
            url=f"{self.base_url_}/api/user/mypage",
            method="post",
        )
        return MyPage.model_validate_json(response.text)

    def get_lesson(self, sid: str):
        response = self._call(
            url=f"{self.base_url_}/api/reservation/modal/{sid}",
            method="get",
        )
        return Lesson.model_validate_json(response.text)

    def get_lesson_history(self, year: int, month: int):
        if not (1900 < year < 2200 and 1 <= month <= 12):
            raise ValueError("Invalid year/month")

        target_month = YearMonth(year, month)
        if target_month in self.history_cache_:
            return self.history_cache_[target_month]

        fetch_month = determine_fetch_center_month(target_month, self.history_cache_)
        fetch_yyyymm = fetch_month.to_yyyymm()
        LOGGER.info(
            f"Fetching lesson history for {fetch_yyyymm} (target: {target_month.to_yyyymm()})"
        )

        response = self._call(
            url=f"{self.base_url_}/api/auth/user/lesson_hist",
            post_data=json.dumps({"target_ym": fetch_yyyymm}),
            method="post",
        )

        data = LessonHistory.model_validate_json(response.text)

        # Store fetched data in cache with filling missing months with empty history
        key = sorted(data.monthly_history.keys())
        # if lessonn count is 0 of head history, it is dummy history for fetching old history, so skip it
        oldest = (
            key[1]
            if len(key) == 2 and data.monthly_history[key[0]].member_count == 0
            else key[0]
        )
        latest = key[-1]
        oldest_month = data.monthly_history[oldest]
        summary_count = oldest_month.summary_count

        for m in YearMonth.range(oldest, latest):
            if m not in data.monthly_history:
                self.history_cache_[m] = MonthHistory(
                    summary_count=summary_count,
                    member_count=0,
                    ticket_count=0,
                    lesson_info=[],
                )
            else:
                self.history_cache_[m] = data.monthly_history[m]

        if target_month not in self.history_cache_:
            return None
        return self.history_cache_[target_month]

    def clear_lesson_history_cache(self):
        self.history_cache_.clear()

    def get_first_lesson_date(self):
        # Fetch the earliest month to find the first lesson date
        self.get_lesson_history(2012, 6)
        assert len(self.history_cache_) > 0, "Failed to fetch lesson history"

        oldest_key = sorted(self.history_cache_.keys())[0]
        oldest_lesson = self.history_cache_[oldest_key].lesson_info[0]
        return datetime.datetime.combine(oldest_lesson.shift_date, oldest_lesson.ls_st)

    def get_studio_list(self):
        response = self._call(
            url=f"{self.base_url_}/api/studio/list",
            post_data=json.dumps({"login_check_flg": 0, "transition_type": 3}),
            method="post",
        )
        data = StudioListResponse.model_validate_json(response.text)
        studio_map = {
            store.stid: store.store_name
            for area in data.area_info
            for pref in area.pref_info
            for store in pref.store_info
        }
        studio_map.update(studios.KNOWN_STUDIOS)  # 閉じたスタジオ情報を補完
        return studio_map

    def get_lesson_calendar_by_store_nocache(
        self,
        *,
        starting_date: datetime.date | None = None,
        store_id: int | None = None,
    ) -> LessonCalendar:
        if starting_date is None:
            starting_date = datetime.date.today()
        elif isinstance(starting_date, datetime.date):
            pass
        else:
            raise TypeError("starting_date must be datetime.date or None")

        if store_id is not None and not isinstance(store_id, int):
            raise TypeError("store_id must be int or None")

        # Convert to str right before _call
        params: dict[str, str] = {
            "mode": "2",
            "shujiku_type": "1",
            "get_direction": "2",  # obtain backward to take 7 days from starting_date
            "get_starting_date": (starting_date + datetime.timedelta(days=7)).strftime(
                "%Y-%m-%d"
            ),
            "trial_lesson": "0",
        }
        if store_id is not None:
            params["search_store[]"] = str(store_id)

        response = self._call(
            url=f"{self.base_url_}/api/reserve/lesson_calendar",
            params=params,
            method="get",
        )
        return LessonCalendar.model_validate_json(response.text)
