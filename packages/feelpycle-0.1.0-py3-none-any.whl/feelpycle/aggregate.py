import datetime
import json
import logging
import os
import pathlib
from collections.abc import Callable, Iterable
from typing import Any

from .api import Account, LessonInfo, MonthHistory, ReservationStatus

LOGGER = logging.getLogger(__name__)


class AccountAggregate:
    """複数の Feelcycle アカウントを束ねて統合管理するクラス。"""

    def __init__(self, accounts: Iterable[Account] | None = None) -> None:
        self._accounts: list[Account] = list(accounts) if accounts else []

    @property
    def accounts(self) -> list[Account]:
        """登録されているアカウントのリストを取得する。"""
        return self._accounts

    def get_account(self, id: str) -> Account | None:
        """指定された ID のアカウントを取得する。"""
        return next((acc for acc in self._accounts if acc.id == id), None)

    def add_account(
        self, id_or_account: str | Account, icon: str | None = None
    ) -> Account:
        """
        アカウントを追加する。すでに同 ID のアカウントが存在する場合は既存のアカウントを返す。

        :param id_or_account: アカウント ID (メールアドレス) または Account インスタンス
        :param icon: 表示用アイコン (絵文字等)
        :return: 登録された Account インスタンス
        """
        if isinstance(id_or_account, Account):
            account = id_or_account
            if account.id:
                existing = self.get_account(account.id)
                if existing is not None:
                    return existing
            self._accounts.append(account)
            return account

        account_id = str(id_or_account)
        account = self.get_account(account_id)
        if account is None:
            account = Account(id=account_id, icon=icon)
            self._accounts.append(account)
        return account

    def ids(self) -> list[str | None]:
        """全アカウントの ID リストを返す。"""
        return [acc.id for acc in self._accounts]

    def icons(self) -> list[str | None]:
        """全アカウントのアイコンリストを返す。"""
        return [acc.icon for acc in self._accounts]

    def __iter__(self):
        return iter(self._accounts)

    def __len__(self) -> int:
        return len(self._accounts)

    def __getitem__(self, index: int) -> Account:
        return self._accounts[index]

    def for_each(
        self, callback_fn: Callable[[Account, int, list[Account]], None]
    ) -> None:
        """全アカウントに対してコールバックを実行する。"""
        for i, acc in enumerate(self._accounts):
            callback_fn(acc, i, self._accounts)

    def is_all_logged_in(self) -> bool:
        """登録されている全アカウントがログイン済みか判定する。"""
        return len(self._accounts) > 0 and all(
            acc.is_logged_in() for acc in self._accounts
        )

    def to_dict(self) -> list[dict[str, Any]]:
        """全アカウントの情報をシリアライズ用辞書リストとして取得する。"""
        return [
            {
                "id": acc.id,
                "icon": acc.icon,
                "session_state": acc.get_session_state(),
            }
            for acc in self._accounts
        ]

    def from_dict(self, data: list[dict[str, Any]], update_csrf: bool = False) -> None:
        """辞書リストからアカウント一覧を復元する。"""
        self._accounts.clear()
        for item in data:
            acc = Account(id=item.get("id"), icon=item.get("icon"))
            session_state = item.get("session_state")
            if session_state:
                acc.set_session_state(session_state)
                if update_csrf:
                    try:
                        acc._update_crsf_token_from_remote()
                    except Exception as e:
                        LOGGER.warning(f"Failed to update CSRF token for {acc.id}: {e}")
            self._accounts.append(acc)

    def to_json(self) -> str:
        """アカウント情報を JSON 文字列としてシリアライズする。"""
        return json.dumps(self.to_dict(), ensure_ascii=False)

    def from_json(self, json_str: str, update_csrf: bool = False) -> None:
        """JSON 文字列からアカウント一覧を復元する。"""
        data = json.loads(json_str) if json_str else []
        self.from_dict(data, update_csrf=update_csrf)

    def persist(
        self, path_or_store: str | os.PathLike | Any, key: str | None = None
    ) -> None:
        """
        アカウント情報を永続化する。
        保存前に各アカウントのレッスン履歴キャッシュはクリアされる。

        :param path_or_store: ファイルパス、またはプロパティストア / 辞書
        :param key: プロパティストア / 辞書を使用する場合のキー
        """
        for acc in self._accounts:
            acc.clear_lesson_history_cache()

        json_str = self.to_json()
        if key is not None:
            if hasattr(path_or_store, "set_property"):
                path_or_store.set_property(key, json_str)
            elif hasattr(path_or_store, "setProperty"):
                path_or_store.setProperty(key, json_str)
            elif isinstance(path_or_store, dict) or hasattr(
                path_or_store, "__setitem__"
            ):
                path_or_store[key] = json_str
            else:
                raise TypeError(
                    f"Unsupported store type: {type(path_or_store)} for persist with key"
                )
        else:
            p = pathlib.Path(path_or_store)
            p.parent.mkdir(parents=True, exist_ok=True)
            p.write_text(json_str, encoding="utf-8")

    def restore(
        self,
        path_or_store: str | os.PathLike | Any,
        key: str | None = None,
        update_csrf: bool = False,
    ) -> None:
        """
        永続化されたデータからアカウント一覧を復元する。

        :param path_or_store: ファイルパス、またはプロパティストア / 辞書
        :param key: プロパティストア / 辞書を使用する場合のキー
        :param update_csrf: 復元時にリモートから CSRF トークンを更新するかどうか
        """
        if key is not None:
            if hasattr(path_or_store, "get_property"):
                json_str = path_or_store.get_property(key)
            elif hasattr(path_or_store, "getProperty"):
                json_str = path_or_store.getProperty(key)
            elif isinstance(path_or_store, dict):
                json_str = path_or_store.get(key, "[]")
            elif hasattr(path_or_store, "__getitem__"):
                try:
                    json_str = path_or_store[key]
                except KeyError:
                    json_str = "[]"
            else:
                raise TypeError(
                    f"Unsupported store type: {type(path_or_store)} for restore with key"
                )
        else:
            p = pathlib.Path(path_or_store)
            if not p.exists():
                json_str = "[]"
            else:
                json_str = p.read_text(encoding="utf-8")

        self.from_json(json_str, update_csrf=update_csrf)

    def get_first_lesson_date(self) -> datetime.datetime | None:
        """
        全アカウントの中で最も古い初回レッスン日時を取得する。

        :return: 最古の初回レッスン日時 (存在しない場合は None)
        """
        timestamps: list[datetime.datetime] = []
        for acc in self._accounts:
            try:
                date = acc.get_first_lesson_date()
                if date is not None:
                    timestamps.append(date)
            except Exception as e:
                LOGGER.warning(f"Failed to get first lesson date for {acc.id}: {e}")

        if not timestamps:
            return None
        return min(timestamps)

    def get_lesson_history(
        self, year: int, month: int, sort_by_date: bool = True
    ) -> MonthHistory:
        """
        全アカウントの指定年月のレッスン履歴を取得し、合算して返す。
        各 LessonInfo にはアカウントの id と icon が付与される。

        :param year: 年
        :param month: 月
        :param sort_by_date: レッスンを受講日時順にソートするかどうか
        :return: 統合された MonthHistory
        """
        member_count = 0
        ticket_count = 0
        all_lessons: list[LessonInfo] = []

        for acc in self._accounts:
            month_history = acc.get_lesson_history(year, month)
            if month_history is None:
                continue

            member_count += month_history.member_count
            ticket_count += month_history.ticket_count

            for lesson in month_history.lesson_info:
                copied = lesson.model_copy(
                    update={
                        "id": acc.id or "",
                        "icon": acc.icon or "",
                    }
                )
                all_lessons.append(copied)

        if sort_by_date:
            all_lessons.sort(key=lambda x: (x.shift_date, x.ls_st))

        return MonthHistory(
            summary_count=0,
            member_count=member_count,
            ticket_count=ticket_count,
            lesson_info=all_lessons,
        )

    def get_reservations(self, sort_by_date: bool = True) -> list[ReservationStatus]:
        """
        全アカウントの予約状況を取得して統合リストとして返す。
        各 ReservationStatus にはアカウントの id と icon が付与される。

        :param sort_by_date: 予約をレッスン日時順にソートするかどうか
        :return: 統合された予約リスト
        """
        all_reservations: list[ReservationStatus] = []

        for acc in self._accounts:
            mypage = acc.mypage()
            if mypage is None:
                raise RuntimeError(f"Account of {acc.id} needs to login")

            for res in mypage.reservation_status:
                copied = res.model_copy(
                    update={
                        "id": acc.id or "",
                        "icon": acc.icon or "",
                    }
                )
                all_reservations.append(copied)

        if sort_by_date:
            all_reservations.sort(key=lambda x: (x.lesson_date, x.lesson_start_time))

        return all_reservations
